"""Согласование конфигурации коллег и прежнего раздела ai без второго CLI."""
import os


def normalize_config(config):
    out = dict(config)
    old = config.get('ai') if isinstance(config.get('ai'), dict) else {}
    current = config.get('llm') if isinstance(config.get('llm'), dict) else {}
    settings = dict(old)
    if old and not current:
        settings.setdefault('enabled', True)
        settings.setdefault('provider', 'local')
        if os.getenv('GEMMA_MODEL'):
            settings['model'] = os.environ['GEMMA_MODEL']
        if os.getenv('AI_PROVIDER'):
            settings['provider'] = os.environ['AI_PROVIDER']
        if str(settings.get('provider', '')).lower() == 'api':
            settings.setdefault('base_url', os.getenv('OPENAI_BASE_URL', 'https://openrouter.ai/api/v1'))
            settings.setdefault('api_key_env', 'OPENAI_API_KEY')
            if os.getenv('OPENAI_MODEL'):
                settings['model'] = os.environ['OPENAI_MODEL']
    # Новый раздел имеет приоритет, чтобы не перезаписать настройки коллег.
    settings.update(current)
    provider = str(settings.get('provider', 'api')).lower()
    if provider == 'ollama':
        settings['provider'] = 'api'
    elif provider == 'off':
        settings['enabled'] = False
    if 'max_tokens' not in settings and 'max_new_tokens' in settings:
        settings['max_tokens'] = settings['max_new_tokens']
    out['llm'] = settings
    return out
