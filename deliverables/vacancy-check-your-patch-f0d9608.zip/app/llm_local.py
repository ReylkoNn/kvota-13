"""Необязательный Transformers-провайдер; не содержит второго конвейера вакансий."""
import logging
from functools import lru_cache

log = logging.getLogger(__name__)


class LocalModelUnavailable(RuntimeError):
    pass


@lru_cache(maxsize=1)
def load_pipeline(model):
    # Эти тяжёлые зависимости необходимы только при llm.provider: local.
    try:
        from transformers import pipeline
        import torch  # noqa: F401
        log.info('Загрузка локальной модели %s', model)
        return pipeline('text-generation', model=model, tokenizer=model,
                        device_map='auto', torch_dtype='auto')
    except Exception as exc:
        raise LocalModelUnavailable('Не удалось загрузить локальную модель или зависимости') from exc


def render_chat(pipe, messages):
    """Адаптация исходного кода: Gemma может не поддерживать роль system."""
    tokenizer = getattr(pipe, 'tokenizer', None)
    merged = [{'role': 'user', 'content': messages[0]['content'] + '\n\n' + messages[1]['content']}]
    if tokenizer is not None:
        for variant in (messages, merged):
            try:
                return tokenizer.apply_chat_template(variant, tokenize=False, add_generation_prompt=True)
            except Exception:
                continue
    return merged[0]['content']


def generate(model, messages, temperature, max_tokens):
    pipe = load_pipeline(model)
    options = {'max_new_tokens': max_tokens, 'do_sample': temperature > 0,
               'return_full_text': False}
    if temperature > 0:
        options['temperature'] = temperature
    result = pipe(render_chat(pipe, messages), **options)
    if not isinstance(result, list) or not result or not isinstance(result[0], dict):
        raise ValueError('Некорректный ответ локальной модели')
    text = result[0].get('generated_text')
    if not isinstance(text, str):
        raise ValueError('Локальная модель не вернула текст')
    return text
