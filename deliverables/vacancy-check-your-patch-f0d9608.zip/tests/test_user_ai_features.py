import copy
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import main
from app.ai_config import normalize_config
from app.ai_support import (apply_question_choice, fallback_issues, filter_rule_duplicates,
                            question_options)
from app.fetch import load_local
from app.llm import LLMError, LLMUnavailable, analyze_vacancy, cache_key
from app.llm_local import render_chat
from app.normalize import normalize
from app.report import save_report
from app.rules import check_rules


class UserAIFeatureTests(unittest.TestCase):
    def setUp(self):
        self.raw = copy.deepcopy(load_local('data/kantkod_sample_vacancies.json')[0])
        self.raw['id'] = 'feature-test'
        self.v = normalize(self.raw)

    def test_fallback_exact_normalized_quote_and_separate_source(self):
        self.v['duty'] = 'Предлагаем ИНТЕРЕСНЫЕ ЗАДАЧИ и обучение.'
        issues = fallback_issues(self.v, [])
        self.assertEqual(len(issues), 1)
        self.assertEqual(issues[0]['quote'], 'ИНТЕРЕСНЫЕ ЗАДАЧИ')
        self.assertEqual(issues[0]['field'], 'duty')
        self.assertEqual(issues[0]['source'], 'fallback')
        self.assertEqual(issues[0]['values'], [])
        self.assertIn(issues[0]['quote'], self.v[issues[0]['field']])

    def test_fallback_does_not_duplicate_salary_rule_or_amount(self):
        self.v.update({'salary': 'Стабильная зарплата', 'salary_min': 0, 'salary_max': 0})
        rules = [{'topic': 'оплата', 'type': 'missing', 'field': 'salary_min'}]
        self.assertEqual(fallback_issues(self.v, rules), [])
        self.assertEqual(len(fallback_issues(self.v, [])), 1)
        self.v['salary_min'] = 25000
        self.assertEqual(fallback_issues(self.v, []), [])

    def test_fallback_ignores_topics_outside_colleague_contract(self):
        self.v['conditions'] = 'Дружный коллектив, полный соцпакет, возможность роста'
        self.assertEqual(fallback_issues(self.v, []), [])

    def test_fallback_not_cached_as_llm_and_disabled_makes_no_fallback(self):
        self.raw['duty'] = 'Интересные задачи'
        cfg = {'llm': {'enabled': True, 'model': 'x', 'base_url': 'http://localhost/v1'},
               'output': {'report_path': 'reports/report.json'}}
        with tempfile.TemporaryDirectory() as tmp:
            cache = str(Path(tmp) / 'cache.json')
            with patch.object(main, 'CACHE_PATH', cache), patch.object(main, 'analyze_vacancy', side_effect=LLMUnavailable('offline')):
                vs, issues = main.run_pipeline([self.raw], 'check', cfg)
                self.assertEqual(vs[0]['_llm_status'], 'fallback')
                self.assertFalse(vs[0]['_llm_checked'])
                self.assertTrue(any(i['source'] == 'fallback' for i in issues['feature-test']))
                self.assertFalse(Path(cache).exists())
                cfg['llm']['enabled'] = False
                vs, issues = main.run_pipeline([self.raw], 'check', cfg)
                self.assertEqual(vs[0]['_llm_status'], 'disabled')
                self.assertFalse(any(i['source'] == 'fallback' for i in issues['feature-test']))

    def test_question_choice_preserves_rule_provenance_and_original(self):
        issue = {'source': 'rules', 'topic': 'график', 'type': 'ambiguous',
                 'field': 'schedule', 'quote': 'Гибкий график',
                 'problem': 'Не указан график', 'recommendation': 'Исходный текст'}
        with patch('app.ai_support.generate_text', return_value='"B"') as generate:
            self.assertTrue(apply_question_choice(self.v, [issue], {'model': 'm'}))
        self.assertEqual(issue['recommendation_original'], 'Исходный текст')
        self.assertEqual(issue['recommendation_source'], 'ai-template-choice')
        self.assertEqual(issue['recommendation_choice'], 'B')
        self.assertEqual(issue['source'], 'rules')
        self.assertEqual(generate.call_args.kwargs['max_tokens'], 8)

    def test_choice_rejects_ambiguity_failure_and_contradiction(self):
        original = {'source': 'rules', 'topic': 'график', 'type': 'ambiguous',
                    'field': 'schedule', 'quote': 'Гибкий график',
                    'problem': 'Проблема', 'recommendation': 'Исходный текст'}
        for value in ('A и B', '', 'объяснение A', RuntimeError('failure')):
            issue = copy.deepcopy(original)
            kwargs = {'side_effect': value} if isinstance(value, Exception) else {'return_value': value}
            with self.subTest(value=value), patch('app.ai_support.generate_text', **kwargs):
                self.assertFalse(apply_question_choice(self.v, [issue], {'model': 'm'}))
                self.assertEqual(issue, original)
        self.assertIsNone(question_options({**original, 'type': 'contradiction'}))
        self.assertIsNone(question_options({**original, 'source': 'llm'}))

    def test_choice_pipeline_opt_in_not_affect_llm_cache(self):
        raw = copy.deepcopy(load_local('data/kantkod_sample_vacancies.json')[1])
        cfg = {'llm': {'enabled': True, 'model': 'x', 'base_url': 'http://localhost/v1',
                       'question_choice': True}, 'output': {'report_path': 'reports/report.json'}}
        with tempfile.TemporaryDirectory() as tmp, patch.object(main, 'CACHE_PATH', tmp + '/cache.json'), \
             patch.object(main, 'analyze_vacancy', return_value=[]) as model, \
             patch('app.ai_support.generate_text', return_value='A') as choice:
            vacancies, issues = main.run_pipeline([raw], 'check', cfg)
            rules = issues[vacancies[0]['id']]
            self.assertTrue(any(i.get('recommendation_choice') == 'A' for i in rules))
            self.assertEqual(choice.call_count, 1)
            cached = json.loads(Path(tmp + '/cache.json').read_text(encoding='utf8'))
            self.assertEqual(list(cached.values()), [[]])
            self.assertEqual(model.call_count, 1)

    def test_duplicate_rule_guard_does_not_drop_new_question(self):
        rule = {'source': 'rules', 'topic': 'график', 'type': 'ambiguous',
                'field': 'schedule', 'quote': 'Гибкий график'}
        duplicate = {'source': 'llm', 'topic': 'график', 'type': 'ambiguous', 'field': 'schedule',
                     'quote': 'Гибкий график', 'problem': 'Не указаны дни и часы',
                     'recommendation': 'Уточнить дни работы'}
        self.assertEqual(filter_rule_duplicates([duplicate], [rule]), [])
        separate = {**duplicate, 'problem': 'Неясно, как согласуется гибкость с фиксированным графиком',
                    'recommendation': 'Как используется гибкость?'}
        self.assertEqual(filter_rule_duplicates([separate], [rule]), [separate])

    def test_local_provider_uses_common_contract_and_no_base_url(self):
        cfg = {'provider': 'local', 'model': 'test-local', 'temperature': 0, 'max_tokens': 128}
        with patch('app.llm_local.generate', return_value='[]') as gen:
            self.assertEqual(analyze_vacancy(self.v, cfg), [])
            self.assertEqual(gen.call_args.args[0], 'test-local')
            self.assertEqual(gen.call_args.args[2:], (0.0, 128))
        with patch('app.llm_local.generate', side_effect=ImportError('no transformers')):
            with self.assertRaises(LLMUnavailable):
                analyze_vacancy(self.v, cfg)
        with patch('app.llm_local.generate', return_value='bad json'):
            with self.assertRaises(LLMError):
                analyze_vacancy(self.v, cfg)
        self.assertNotEqual(cache_key(self.v, cfg), cache_key(self.v, {**cfg, 'provider': 'api',
                                                                       'base_url': 'http://x/v1'}))

    def test_local_chat_template_system_role_fallback(self):
        class Tokenizer:
            def apply_chat_template(self, messages, **kwargs):
                if messages[0]['role'] == 'system': raise ValueError('no system')
                return messages[0]['content']
        class Pipe: tokenizer = Tokenizer()
        text = render_chat(Pipe(), [{'role': 'system', 'content': 'system instructions'},
                                    {'role': 'user', 'content': 'vacancy'}])
        self.assertIn('system instructions', text)
        self.assertIn('vacancy', text)

    def test_old_ai_config_and_new_llm_precedence(self):
        old = {'ai': {'enabled': True, 'provider': 'local', 'model': 'local-model', 'max_new_tokens': 512}}
        cfg = normalize_config(old)['llm']
        self.assertEqual(cfg['provider'], 'local')
        self.assertEqual(cfg['max_tokens'], 512)
        both = normalize_config({**old, 'llm': {'enabled': True, 'model': 'team-model', 'provider': 'ollama'}})['llm']
        self.assertEqual(both['model'], 'team-model')
        self.assertEqual(both['provider'], 'api')
        self.assertFalse(normalize_config({'llm': {'enabled': True, 'provider': 'off'}})['llm']['enabled'])

    def test_model_limit_keeps_rules_and_marks_status(self):
        raw = load_local('data/kantkod_sample_vacancies.json')[:2]
        cfg = {'llm': {'enabled': True, 'model': 'x', 'base_url': 'http://localhost/v1',
                       'max_vacancies_for_ai': 1}, 'output': {'report_path': 'reports/report.json'}}
        with tempfile.TemporaryDirectory() as tmp, patch.object(main, 'CACHE_PATH', tmp + '/cache'), \
             patch.object(main, 'analyze_vacancy', return_value=[]) as model:
            vs, result = main.run_pipeline(raw, 'check', cfg)
            self.assertEqual(model.call_count, 1)
            self.assertEqual(vs[1]['_llm_status'], 'skipped_limit')
            self.assertFalse(vs[1]['_llm_checked'])
            self.assertGreater(len(result[vs[1]['id']]), 0)

    def test_report_tracks_own_vacancy_status(self):
        self.v.update({'_llm_checked': False, '_llm_status': 'fallback'})
        with tempfile.TemporaryDirectory() as tmp:
            path = tmp + '/report.json'
            save_report([self.v], {self.v['id']: []}, 'check', None, path)
            record = json.loads(Path(path).read_text(encoding='utf8'))['vacancies'][0]
            self.assertFalse(record['llm_checked'])
            self.assertEqual(record['llm_status'], 'fallback')

    def test_diagnostics_include_rejection_without_secret(self):
        good = {'topic': 'обязанности', 'type': 'ambiguous', 'field': 'duty', 'quote': self.v['duty'],
                'values': [], 'problem': 'Неясно', 'recommendation': 'Уточнить'}
        invalid = {**good, 'quote': 'несуществующий текст'}
        with tempfile.TemporaryDirectory() as tmp, patch('app.llm.generate_text', return_value=json.dumps([good, invalid])):
            with self.assertRaises(LLMError):
                analyze_vacancy(self.v, {'provider': 'local', 'model': 'mock', 'debug_dir': tmp})
            debug = json.loads(next(Path(tmp).glob('*.json')).read_text(encoding='utf8'))
            self.assertTrue(debug['candidates'][0]['accepted'])
            self.assertFalse(debug['candidates'][1]['accepted'])
            self.assertTrue(debug['candidates'][1]['reason'])

    def test_choice_survives_invalid_model_json_as_mixed(self):
        raw = copy.deepcopy(load_local('data/kantkod_sample_vacancies.json')[1])
        cfg = {'llm': {'enabled': True, 'model': 'x', 'base_url': 'http://localhost/v1',
                       'question_choice': True}, 'output': {'report_path': 'reports/report.json'}}
        with tempfile.TemporaryDirectory() as tmp, patch.object(main, 'CACHE_PATH', tmp + '/cache.json'), \
             patch.object(main, 'analyze_vacancy', side_effect=LLMError('bad json')), \
             patch('app.ai_support.generate_text', return_value='B'):
            vacancies, issues = main.run_pipeline([raw], 'check', cfg)
            self.assertEqual(vacancies[0]['_llm_status'], 'mixed')
            self.assertFalse(vacancies[0]['_llm_checked'])
            self.assertTrue(any(i.get('recommendation_choice') == 'B' for i in issues[vacancies[0]['id']]))
            self.assertFalse(Path(tmp + '/cache.json').exists())

    def test_prompt_probe_uses_common_provider_and_not_pipeline_cache(self):
        from tools.prompt_probe import run_probe
        with patch('tools.prompt_probe.generate_text', side_effect=['[]', 'ДА']) as generate:
            results = run_probe([self.v], {'model': 'model'})
        self.assertEqual(results[0]['issues'], [])
        self.assertEqual(results[1]['answer'], 'ДА')
        self.assertEqual(generate.call_count, 2)

    def test_quality_guard_does_not_remove_vague_002(self):
        from app.llm import validate_quotes
        vacancy = normalize(load_local('data/kantkod_sample_vacancies.json')[1])
        issue = {'topic': 'обязанности', 'type': 'ambiguous', 'field': 'duty',
                 'quote': vacancy['duty'], 'values': [], 'problem': 'Не ясны конкретные обязанности',
                 'recommendation': 'Уточните конкретные обязанности'}
        self.assertEqual(len(validate_quotes([issue], vacancy)), 1)

if __name__ == '__main__':
    unittest.main()
