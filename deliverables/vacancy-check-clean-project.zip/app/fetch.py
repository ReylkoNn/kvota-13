import requests
import json

class ApiError(Exception):
    pass



def unwrap(data):
    if isinstance(data, dict):
        for key in ('results', 'data', 'vacancies', 'items'):
            if key in data and isinstance(data[key], (dict, list)):
                return unwrap(data[key])
        if isinstance(data.get('vacancy'), dict):
            return [data['vacancy']]
        raise ApiError('Некорректный формат данных: список вакансий не найден')
    if not isinstance(data, list):
        raise ApiError('Некорректный формат данных: список вакансий не найден')
    if not all(isinstance(item, dict) and isinstance(item.get('vacancy', item), dict) for item in data):
        raise ApiError('Некорректная запись вакансии')
    return [item.get('vacancy', item) for item in data]

def fetch_page(url, page, limit):
    try:
        resp = requests.get(url, params={'offset': page, 'limit': limit}, timeout=50)
        resp.raise_for_status()
        data = resp.json()
    except ValueError as e:
        raise ApiError('API вернул не JSON') from e
    except requests.RequestException as e:
        raise ApiError(f'API недоступен: {e}') from e
    return unwrap(data)

def fetch_vacancies(url, page_size, max_vacancies, max_pages=100):
    if page_size < 1 or max_vacancies < 1 or max_pages < 1:
        raise ValueError('Лимиты страниц и вакансий должны быть положительными')
    page_size = min(page_size, 100, max(1, (max_vacancies + 1) // 2))
    vacancies = []
    seen = set()
    for page in range(max_pages):
        batch = fetch_page(url, page * page_size, page_size)
        if not batch:
            break
        for vacancy in batch:
            raw_id = vacancy.get('id')
            key = str(raw_id).strip() if raw_id is not None else ''
            if key and key in seen:
                continue
            if key:
                seen.add(key)
            vacancies.append(vacancy)
            if len(vacancies) >= max_vacancies:
                break
        if len(vacancies) >= max_vacancies or len(batch) < page_size:
            break
    if not vacancies:
        raise ApiError('API вернул 0 вакансий - проверь URL и регион')
    return vacancies

def load_local(path):
    with open(path, encoding='utf-8') as f:
        data = json.load(f)
    return unwrap(data)
