import re

def issue(topic, type_, field, problem, recommendation, quote='', values=None):
    return {
        'topic': topic,
        'type': type_,
        'field': field,
        'quote': quote,
        'values': values or [],
        'problem': problem,
        'recommendation': recommendation,
        'source': 'rules',
    }
def salary_missing(v):
    if not v['salary_min'] and not v['salary_max'] and not re.search(r'[1-9]\d*', str(v.get('salary') or '')):
        return issue('оплата', 'missing', 'salary_min',
                     'Зарплата не указана.',
                     'Уточнить у работодателя размер оплаты.')

def salary_no_max(v):
    if v['salary_min'] and not v['salary_max']:
        return issue('оплата', 'missing', 'salary_max',
                     f"Указана только нижняя граница зарплаты: от {v['salary_min']}.",
                     'Уточнить верхнюю границу или фиксированную сумму.')

def employment_missing(v):
    if not v['employment']:
        return issue('тип занятости', 'missing', 'employment',
                     'Не указан тип занятости.',
                     'Уточнить: полная, частичная, проектная работа или стажировка.')

def duty_missing(v):
    if not v['duty']:
        return issue('обязанности', 'missing', 'duty',
                     'Обязанности не указаны.',
                     'Уточнить, что входит в работу.')


def requirements_missing(v):
    if not (v['requirements'] or v['requirement.qualification'] or v['qualification']):
        return issue('требования', 'missing', 'requirements',
                     'Требования к кандидату не указаны.',
                     'Уточнить требования к кандидату.')

GENERIC_TITLES = {'специалист', 'сотрудник', 'работник', 'менеджер', 'помощник', 'оператор'}


def title_vague(v):
    title = v['job-name']
    if not title:
        return issue('название', 'missing', 'job-name',
                     'Не указано название вакансии.',
                     'Уточнить должность.')
    if title.lower() in GENERIC_TITLES:
        return issue('название', 'ambiguous', 'job-name',
                     f'Название «{title}» не говорит, чем человек будет заниматься.',
                     'Уточнить должность и направление работы.',
                     quote=title)


SCHEDULE_DETAILS = re.compile(r'\d{1,2}[:.]\d{2}|\d/\d|сутки через|через сутки|дневн|ночн', re.IGNORECASE)
TEXT_FIELDS = ['scheduleTypeComment', 'duty', 'requirements', 'requirement.qualification', 'conditions']


def schedule_vague(v):
    schedule = v['schedule']
    if not schedule:
        return issue('график', 'missing', 'schedule',
                     'График работы не указан.',
                     'Уточнить дни и часы работы.')
    if not re.search(r'гибк|сменн', schedule, re.IGNORECASE):
        return None
    shift = v['shift'] or []
    if not isinstance(shift, list):
        shift = [str(shift)]
    texts = [schedule] + [str(v[f] or '') for f in TEXT_FIELDS] + [str(x) for x in shift]
    if SCHEDULE_DETAILS.search(' '.join(texts)):
        qualification = v.get('requirement.qualification') or ''
        unspecified = re.search(r'гибк\w*\s+график[^.!?;]{0,60}?без\s+уточнен\w*\s+правил', qualification, re.I)
        if unspecified:
            return issue('график', 'ambiguous', 'requirement.qualification',
                         'Часы указаны, но правила гибкого графика не уточнены.',
                         'Уточнить, какие часы или дни можно менять и как согласуется график.',
                         quote=unspecified.group())
        return None
    return issue('график', 'ambiguous', 'schedule',
                 f'График «{schedule}» указан без дней и часов.',
                 'Уточнить дни, часы работы и порядок смен.',
                 quote=schedule)

def employment_schedule_conflict(v):
    employment = (v['employment'] or '').lower()
    schedule = (v['schedule'] or '').lower()
    full_job = 'полная' in employment
    part_day = 'неполный' in schedule
    part_job = 'частичная' in employment
    full_day = 'полный рабочий день' in schedule
    if (full_job and part_day) or (part_job and full_day):
        return issue('тип занятости', 'contradiction', 'employment',
                     f"Тип занятости «{v['employment']}» не сходится с графиком «{v['schedule']}».",
                     'Уточнить, полная это занятость или частичная.',
                     quote=v['employment'], values=[v['employment'], v['schedule']])


def address_vague(v):
    address = v['addresses']
    if not address:
        return issue('место работы', 'missing', 'addresses',
                     'Адрес работы не указан.',
                     'Уточнить адрес рабочего места.')
    if ',' not in address and 'област' in address.lower():
        return issue('место работы', 'ambiguous', 'addresses',
                     'Указан только регион, без города и адреса.',
                     'Уточнить город и адрес рабочего места.',
                     quote=address)


EXPERIENCE = re.compile(r'(?:не менее|от|более|минимум)\s+(\d+)(?:-?х)?\s*(?:лет|года|год)', re.IGNORECASE)


def experience_conflict(v):
    value = v.get('requirement.experience')
    try:
        positive = not isinstance(value, bool) and float(value) > 0
    except (ValueError, TypeError):
        positive = False
    text = v.get('requirement.qualification') or ''
    match = re.search(r'опыт\s+работы[^.!?;]{0,100}?приветствуется', text, re.I)
    if match and positive and not re.search(r'не\s+приветствуется$', match.group(), re.I):
        return issue('требования', 'ambiguous', 'requirement.qualification | requirement.experience',
                     'В тексте опыт желателен, а в отдельном поле задано значение; связь неясна.',
                     'Проверить поле опыта и уточнить, является ли опыт обязательным.',
                     quote=match.group(), values=[match.group(), str(value)])


def remote_office_conflict(v):
    duty = v.get('duty') or ''
    qualification = v.get('requirement.qualification') or ''
    remote = re.search(r'полностью\s+(?:дистанционн\w*|удал[её]нн\w*)', duty, re.I)
    office = re.search(r'обязательн\w*\s+(?:ежедневн\w*\s+)?присутстви\w*\s+в\s+офисе', qualification, re.I)
    if not remote or not office:
        return None
    if (re.search(r'(?:не|без)\s+$', duty[max(0, remote.start()-15):remote.start()], re.I)
            or re.match(r'\s+(?:работ\w*\s+)?не\s+(?:предусмотрен\w*|возможн\w*|допускается)', duty[remote.end():], re.I)
            or re.search(r'(?:не|без)\s+$', qualification[max(0, office.start()-15):office.start()], re.I)
            or re.match(r'\s+не\s+(?:требуется|нужно|обязательно)', qualification[office.end():], re.I)):
        return None
    return issue('место работы', 'contradiction', 'duty | requirement.qualification',
                 'Полностью дистанционная работа и обязательное присутствие в офисе могут не сочетаться.',
                 'Проверить оба условия и уточнить формат работы.',
                 quote=remote.group(), values=[remote.group(), office.group()])

RULES = [title_vague, duty_missing, requirements_missing, salary_missing, salary_no_max,
         employment_missing, employment_schedule_conflict, schedule_vague,
         address_vague, experience_conflict, remote_office_conflict]
         
def check_rules(v):
    issues = []
    for rule in RULES:
        try:
            found = rule(v)
        except Exception as e:
            print(f"правило {rule.__name__} упало на {v.get('id')}: {e}")
            continue
        if found:
            issues.append(found)
    return issues