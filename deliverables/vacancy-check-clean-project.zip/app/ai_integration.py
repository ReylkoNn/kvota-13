"""Подключение модели к нормализованной вакансии и повторное использование ответов."""
import hashlib
import json
import logging
import os
from pathlib import Path

from .ai_support import ai_view
from .llm import ApiAnalyzer, FallbackAnalyzer, GemmaLocalAnalyzer, _valid_remark

log = logging.getLogger(__name__)
CACHE_VERSION = 'vacancy-ai-v1'

CHOICES = {
    'оплата': ('Укажите конкретную сумму или вилку оплаты.',
               'Уточните сумму оплаты и условия, от которых зависит её размер.'),
    'обязанности': ('Перечислите основные задачи сотрудника.',
                    'Уточните основные задачи сотрудника и зоны его ответственности.'),
    'требования': ('Уточните обязательные навыки и требуемый опыт работы.',
                   'Уточните обязательные навыки и требования к образованию.'),
    'график': ('Укажите дни недели, часы работы и продолжительность смен.',
               'Уточните дни и часы смен и порядок формирования графика.'),
    'место работы': ('Укажите город и адрес или район места работы.',
                     'Уточните город, место и формат работы: в офисе или удалённо.'),
    'тип занятости': ('Проверьте и укажите тип занятости: полная или частичная.',
                      'Проверьте и уточните тип занятости и предполагаемую длительность работы.'),
}


def _model(cfg):
    if not cfg.get('enabled', True) or cfg.get('provider') == 'off':
        return None
    provider = cfg.get('provider', 'local')
    if provider in ('api', 'ollama'):
        key = os.environ.get(cfg.get('api_key_env', 'OPENAI_API_KEY'), '') or os.environ.get('OPENAI_API_KEY', '')
        if provider == 'ollama':
            key = key or 'ollama'
        if not key:
            raise ValueError('Не задан OPENAI_API_KEY')
        base = os.environ.get('OPENAI_BASE_URL', cfg.get('base_url', 'http://localhost:11434/v1'))
        name = os.environ.get('OPENAI_MODEL', cfg.get('model', ''))
        return ApiAnalyzer(base, key, name, temperature=float(cfg.get('temperature', 0.3)))
    if provider != 'local':
        raise ValueError('Неизвестный провайдер модели')
    return GemmaLocalAnalyzer(cfg.get('model', 'google/gemma-2-2b-it'),
                              int(cfg.get('max_new_tokens', 512)), float(cfg.get('temperature', 0.3)))


def _key(view, cfg, rule):
    code = hashlib.sha256()
    for name in ('llm.py', 'ai_support.py', 'ai_integration.py'):
        code.update((Path(__file__).parent / name).read_bytes())
    identity = {'version': CACHE_VERSION, 'code': code.hexdigest(), 'raw': view['raw'],
                'provider': cfg.get('provider', 'local'), 'model': os.environ.get('OPENAI_MODEL', cfg.get('model')),
                'base_url': os.environ.get('OPENAI_BASE_URL', cfg.get('base_url')),
                'temperature': cfg.get('temperature', 0.3), 'max_new_tokens': cfg.get('max_new_tokens', 512),
                'rule': rule}
    return hashlib.sha256(json.dumps(identity, sort_keys=True, ensure_ascii=False,
                                     separators=(',', ':')).encode('utf-8')).hexdigest()


def _team_issues(issues, source='llm'):
    return [{**item, 'topic': item['topic'].lower(), 'type': 'ambiguous',
             'values': [], 'source': source} for item in issues]


class AIIntegration:
    def __init__(self, cfg, mode):
        self.cfg = cfg
        self.mode = mode
        self.model = None
        self.model_error = None
        self.cache_path = Path(cfg.get('cache_path', 'reports/ai-cache-v1.json'))
        self.cache = {}
        if mode == 'api' and cfg.get('cache_enabled', True):
            try:
                payload = json.loads(self.cache_path.read_text(encoding='utf-8'))
                if isinstance(payload, dict) and payload.get('version') == CACHE_VERSION and isinstance(payload.get('entries'), dict):
                    self.cache = payload['entries']
            except FileNotFoundError:
                pass
            except (OSError, ValueError) as exc:
                log.warning('Не удалось прочитать кэш ИИ: %s', exc)

    def _get_model(self):
        if self.model is None and self.model_error is None:
            try:
                self.model = _model(self.cfg)
            except Exception as exc:
                self.model_error = str(exc)
                log.warning('Не удалось настроить ИИ: %s', exc)
        return self.model

    def _save(self):
        try:
            self.cache_path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.cache_path.with_suffix(self.cache_path.suffix + '.tmp')
            tmp.write_text(json.dumps({'version': CACHE_VERSION, 'entries': self.cache}, ensure_ascii=False), encoding='utf-8')
            os.replace(tmp, self.cache_path)
        except (OSError, ValueError, TypeError) as exc:
            log.warning('Не удалось сохранить кэш ИИ: %s', exc)

    def analyze(self, v, rule_issues):
        view = ai_view(v)
        selected = next((i for i, r in enumerate(rule_issues)
                         if r.get('source') == 'rules' and r.get('type') == 'missing'
                         and r.get('topic') in CHOICES), None)
        rule = rule_issues[selected] if selected is not None else None
        cacheable = self.mode == 'api' and self.cfg.get('cache_enabled', True) and self.cfg.get('enabled', True)
        key = _key(view, self.cfg, rule) if cacheable else None
        entry = self.cache.get(key) if key else None
        model = self._get_model() if self.cfg.get('enabled', True) and self.cfg.get('provider') != 'off' else None
        if model is not None and isinstance(entry, dict) and isinstance(entry.get('issues'), list):
            checked = [_valid_remark(item, view) for item in entry['issues']]
            choice = entry.get('choice')
            if all(item is not None for item in checked) and choice in (None, 'A', 'B'):
                self._apply_choice(rule_issues, selected, choice)
                return _team_issues(checked), model.name, True
        choice = None
        if model is not None:
            if selected is not None:
                options = dict(zip(('A', 'B'), CHOICES[rule['topic']]))
                try:
                    choice = model.choose_option(view, rule, options)
                except Exception as exc:
                    log.warning('Не удалось выбрать рекомендацию ИИ: %s', exc)
                if choice not in options:
                    choice = None
                self._apply_choice(rule_issues, selected, choice)
            try:
                issues = model.analyze(view)
                if not isinstance(issues, list):
                    raise ValueError('Некорректный ответ модели')
                issues = [valid for item in issues if (valid := _valid_remark(item, view)) is not None]
                if key:
                    self.cache[key] = {'issues': issues, 'choice': choice}
                    if len(self.cache) > 2000:
                        self.cache = dict(list(self.cache.items())[-2000:])
                    self._save()
                return _team_issues(issues), model.name, False
            except Exception as exc:
                log.warning('Ошибка модели: %s; используются правила и fallback', exc)
        fallback = _team_issues(FallbackAnalyzer().analyze(view), 'fallback')
        return fallback, 'mixed' if choice else 'fallback', False

    def _apply_choice(self, issues, index, choice):
        if index is None or choice not in ('A', 'B'):
            return
        issue = issues[index]
        old = issue['recommendation']
        selected = CHOICES[issue['topic']][0 if choice == 'A' else 1]
        issue['recommendation'] = selected
        issue['recommendation_original'] = old
        issue['recommendation_source'] = 'ai-template-choice'
        issue['recommendation_choice'] = choice
        issue['recommendation_model'] = self.cfg.get('model')
