"""Представление исходных полей для модели и проверки цитат."""
import re

TOPIC_ORDER = ["Название", "Обязанности", "Требования", "Оплата", "График",
               "Место работы", "Тип занятости", "Описание"]

_ALIASES = {
    "id": ["id", "vacancyId", "vacancy_id", "ID"],
    "title": ["vacancyName", "job-name", "name", "title", "position", "profession", "должность"],
    "company": ["companyName", "company", "employerName", "organization", "работодатель"],
    "description": ["description", "vacancyDescription", "text", "comment", "описание"],
    "duties": ["duties", "duty", "responsibilities", "jobDuties", "обязанности", "функции"],
    "requirements": ["requirements", "requirement", "skills", "требования", "навыки"],
    "salary_text": ["salary", "salaryText", "salary_text", "pay", "оплата", "зарплата"],
    "schedule_type": ["scheduleType", "schedule", "workSchedule", "график"],
    "schedule_text": ["scheduleText", "workTime", "режимРаботы"],
    "employment_type": ["employmentType", "employment", "typeOfEmployment", "busyType", "занятость"],
    "workplace": ["workPlace", "workplace", "place", "местоРаботы"],
    "address": ["address", "location", "адрес"],
    "city": ["city", "город"],
    "url": ["url", "vac_url", "link", "vacancyUrl", "cardUrl", "ссылка"],
}


def ai_view(v):
    raw = v.get('raw', {})
    requirement = raw.get('requirement') if isinstance(raw.get('requirement'), dict) else {}
    def text(value):
        return str(value).strip() if isinstance(value, (str, int, float)) and not isinstance(value, bool) else ''
    return {
        'raw': raw, 'id': text(v.get('id')),
        'requirements': text(raw.get('requirements')),
        'requirement_qualification': text(requirement.get('qualification')),
        'requirement_education': text(requirement.get('education')),
        'requirement_experience': text(requirement.get('experience')),
        'salary_min': v.get('salary_min'), 'salary_max': v.get('salary_max'),
        'salary_text': text(raw.get('salary')),
        'schedule_type': text(raw.get('schedule')),
        'schedule_text': text(raw.get('scheduleTypeComment')),
        'description': text(raw.get('description')),
    }


def _has_pay_amount(v):
    for value in (v.get('salary_min'), v.get('salary_max')):
        try:
            if float(value) > 0:
                return True
        except (ValueError, TypeError):
            pass
    if re.search(r"[1-9]\d*", v.get('salary_text', '')):
        return True
    description = v.get('description', '')
    return bool(re.search(r"(?:зарплат\w*|оплат\w*|оклад\w*)[^.\n]{0,60}[1-9]\d*\s*(?:руб\w*|₽|тыс\w*)", description, re.I))
