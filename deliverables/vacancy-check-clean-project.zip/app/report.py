import json
import os
from datetime import datetime

def save_report(vacancies, issues_dict, mode, model, report_path):
    statuses = [v.get('ai_status', 'fallback') for v in vacancies]
    used_model = any(x in ('gemma-local', 'transformers-local', 'api', 'mixed') for x in statuses)
    all_issues = issues_dict if isinstance(issues_dict, list) else [issues_dict.get(v.get('id'), []) for v in vacancies]
    report_data = {
        "generated_at": datetime.now().astimezone().isoformat(),
        "mode": mode,
        "model": model if used_model else None,
        "requested_model": model,
        "ai_status": statuses[0] if statuses and len(set(statuses)) == 1 else ('mixed' if statuses else 'off'),
        "total": len(vacancies),
        "ai_generated_issues": sum(1 for group in all_issues for r in group if r.get('source') == 'llm'),
        "ai_selected_recommendations": sum(1 for group in all_issues for r in group if r.get('recommendation_source') == 'ai-template-choice'),
        "ai_cache_hits": sum(1 for v in vacancies if v.get('ai_cache_hit')),
        "vacancies": []
    }
    for v, issues in zip(vacancies, all_issues):
        v_id = v.get('id')
        if mode == 'api' and not v_id:
            continue
        report_data['vacancies'].append({
            'id': v_id or '', 'url': v.get('vac_url') or '',
            'ai_status': v.get('ai_status', 'fallback'),
            'ai_cache_hit': bool(v.get('ai_cache_hit')), 'issues': issues,
        })
    report_data['total'] = len(report_data['vacancies'])
    os.makedirs(os.path.dirname(report_path) or '.', exist_ok=True)
    tmp_path = report_path + '.tmp'
    with open(tmp_path, 'w', encoding='utf-8') as f:
        json.dump(report_data, f, ensure_ascii=False, indent=2)
    os.replace(tmp_path, report_path)
    print(f"Отчет успешно сохранен в {report_path}")

def deduplicate_issues(issues):
    if not issues:
        return []

    # Приоритет: 
    # 0. LLM contradiction (самое сильное)
    # 1. Rules contradiction
    # 2. LLM ambiguous
    # 3. Rules ambiguous/missing

    def priority(issue):
        source = issue.get("source", "rules")
        type_ = issue.get("type", "ambiguous")
        if source == "llm" and type_ == "contradiction": return 0
        if source == "rules" and type_ == "contradiction": return 1
        if source == "llm": return 2
        return 3
    sorted_issues = sorted(issues, key=priority)
    
    seen = set()
    result = []
    
    for issue in sorted_issues:
        # Разные цитаты и пропуски с разными проблемами сохраняются.
        quote = str(issue.get('quote') or '').casefold().strip()
        key = (issue.get('topic'), issue.get('type'), issue.get('field'), quote,
               '' if quote else str(issue.get('problem') or '').casefold().strip())
        
        if key not in seen:
            seen.add(key)
            result.append(issue)
            
    return result