import sys
import logging
import argparse
import time
import yaml
import json
import os

from app.fetch import fetch_vacancies, load_local, ApiError
from app.normalize import normalize, normalize_all
from app.rules import check_rules

from app.report import save_report, deduplicate_issues
from app.ai_integration import AIIntegration


# Настройка логов
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def load_config(path="config.yaml"):
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def run_pipeline(raw_data, mode, cfg):
    vacancies = normalize_all(raw_data) if mode == 'api' else [normalize(v) for v in raw_data]
    all_issues = []
    ai_cfg = dict(cfg.get('llm', {}))
    cache_path = ai_cfg.get('cache_path', 'reports/ai-cache-v1.json')
    protected = (cfg['output']['report_path'], cfg.get('error_report', 'reports/error.json'))
    if os.path.abspath(cache_path) in {os.path.abspath(p) for p in protected}:
        logger.warning('Путь кэша совпадает с отчётом: кэш отключён')
        ai_cfg['cache_enabled'] = False
    analyzer = AIIntegration(ai_cfg, mode)
    max_ai = int(ai_cfg.get('max_vacancies_for_ai', 200))
    for index, v in enumerate(vacancies):
        logger.info('Анализ вакансии %d/%d (ID: %s)', index + 1, len(vacancies), v.get('id'))
        issues = check_rules(v)
        if index < max_ai:
            ai_issues, status, cache_hit = analyzer.analyze(v, issues)
        else:
            ai_issues, status, cache_hit = [], 'off', False
        v['ai_status'] = status
        v['ai_cache_hit'] = cache_hit
        all_issues.append(deduplicate_issues(issues + ai_issues))
    return vacancies, all_issues

def record_fetch_error(error, cfg):
    path = cfg.get('error_report', 'reports/error.json')
    report = cfg['output']['report_path']
    if os.path.abspath(path) == os.path.abspath(report):
        path = report + '.error.json'
    try:
        os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump({'error': str(error), 'source': cfg['source']['url']}, f, ensure_ascii=False, indent=2)
    except OSError as exc:
        logger.error('Не удалось записать ошибку API: %s', exc)


def fetch_with_retries(cfg):
    max_retries = cfg['source'].get('max_retries', 3)
    delay = cfg['source'].get('retry_delay_seconds', 5)
    
    if not isinstance(max_retries, int) or isinstance(max_retries, bool) or max_retries < 1:
        raise ValueError('max_retries должен быть положительным целым числом')
    if not isinstance(delay, (int, float)) or isinstance(delay, bool) or delay < 0:
        raise ValueError('retry_delay_seconds должен быть неотрицательным числом')

    for attempt in range(1, max_retries + 1):
        try:
            logger.info(f"Попытка загрузки данных ({attempt}/{max_retries})...")
            return fetch_vacancies(
                cfg['source']['url'], 
                cfg['source']['page_size'], 
                cfg['source']['max_vacancies'],
                cfg['source'].get('max_pages', 100)
            )
        except ApiError as e:
            logger.warning(f"Сбой API (попытка {attempt}/{max_retries}): {e}")
            if attempt == max_retries:
                #  пробрасываем ошибку выше чтобы внешний except не дал перезаписать старый отчет
                logger.error("Все попытки исчерпаны.")
                raise e
            logger.info(f"Ждем {delay} секунд перед следующей попыткой...")
            time.sleep(delay)

def main():
    common = argparse.ArgumentParser(add_help=False, argument_default=argparse.SUPPRESS)
    common.add_argument('--config', help='Путь к YAML-конфигурации')
    common.add_argument('--output', help='Путь к отчёту')
    common.add_argument('--no-ai', action='store_true', help='Без модели')
    parser = argparse.ArgumentParser(description="Vacancy Checker", parents=[common])
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("run", parents=[common], help="Запуск через API")
    check_parser = subparsers.add_parser("check", parents=[common], help="Проверка локального JSON")
    check_parser.add_argument("--input", required=True, help="Путь к файлу")
    subparsers.add_parser("schedule", parents=[common], help="Работа по расписанию")
    args = parser.parse_args()
    cfg = load_config(getattr(args, 'config', 'config.yaml'))
    if getattr(args, 'no_ai', False):
        cfg.setdefault('llm', {})['enabled'] = False
    if getattr(args, 'output', None):
        cfg['output']['report_path'] = args.output

    try:
        if args.command == "run":
            logger.info("Запуск через API...")
            raw = fetch_with_retries(cfg) 
            vacancies, issues = run_pipeline(raw, mode="api", cfg=cfg)
            save_report(vacancies, issues, mode="api", model=cfg.get('llm', {}).get('model'), report_path=cfg['output']['report_path'])
            logger.info(f"Обработано вакансий: {len(issues)}")

        elif args.command == "check":
            logger.info(f"Запуск проверки файла: {args.input}")
            raw = load_local(args.input)
            vacancies, issues = run_pipeline(raw, mode="check", cfg=cfg)
            save_report(vacancies, issues, mode="check", model=cfg.get('llm', {}).get('model'), report_path=cfg['output']['report_path'])
            logger.info(f"Обработано вакансий: {len(issues)}")

        elif args.command == "schedule":
            logger.info("Запуск по расписанию...")
            hours = cfg['schedule']['every_hours']
            if not isinstance(hours, (int, float)) or isinstance(hours, bool) or hours <= 0:
                raise ValueError('schedule.every_hours должен быть положительным числом')
            logger.info(f"Интервал: каждые {hours} часов. (Нажми Ctrl+C для выхода)")
            while True:
                try:
                    logger.info("Плановая загрузка данных...")
                    raw = fetch_with_retries(cfg)
                    vacancies, issues = run_pipeline(raw, mode="api", cfg=cfg)
                    save_report(vacancies, issues, mode="api", model=cfg.get('llm', {}).get('model'), report_path=cfg['output']['report_path'])
                    logger.info(f"Плановый отчет сохранен. Ждем {hours} ч. ...")
                    time.sleep(hours * 3600)
                except KeyboardInterrupt:
                    logger.info("\nРабота остановлена пользователем (Ctrl+C). Выход.")
                    sys.exit(0)
                except Exception as e:
                    # если тут, то все ретраи провалились
                    logger.error(f"Ошибка планового запуска: {e}. Ждем следующего планового запуска.")
                    if isinstance(e, ApiError):
                        record_fetch_error(e, cfg)
                    time.sleep(hours * 3600) # если API совсем лег, ждем до следующего часа
    except KeyboardInterrupt:
        logger.info("\nРабота остановлена пользователем (Ctrl+C)")
        sys.exit(0)
    except ApiError as e:
        logger.error(f"Ошибка API: {e}. Старый отчет не тронут.")
        record_fetch_error(e, cfg)
        sys.exit(1)
    except Exception as e:
        logger.exception(f"Критическая ошибка: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()