import json
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse
import unittest
from pathlib import Path
from unittest.mock import patch

import main
from app.ai_integration import AIIntegration
from app.fetch import ApiError, fetch_vacancies, unwrap
from app.normalize import normalize
from app.report import deduplicate_issues, save_report
from app.rules import check_rules

ROOT = Path(__file__).resolve().parent.parent
SAMPLE = json.loads((ROOT / 'data/kantkod_sample_vacancies.json').read_text(encoding='utf8'))


class FakeModel:
    name = 'gemma-local'
    def __init__(self, fail=False):
        self.calls = 0
        self.choices = 0
        self.fail = fail
    def choose_option(self, vacancy, rule, options):
        self.choices += 1
        return 'A'
    def analyze(self, vacancy):
        self.calls += 1
        if self.fail:
            raise ValueError('invalid JSON')
        return [{'topic': 'Обязанности', 'field': 'duty',
                 'quote': 'Выполнение различных поручений руководителя.',
                 'problem': 'Неясно, какие поручения.',
                 'recommendation': 'Уточните поручения.', 'severity': 'средняя'}]


class IntegrationTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name)
        self.cfg = {'llm': {'provider': 'local', 'enabled': True, 'model': 'test',
                            'cache_path': str(self.path / 'cache-v1.json')},
                    'output': {'report_path': str(self.path / 'report.json')},
                    'source': {'url': 'http://example.invalid', 'page_size': 1,
                               'max_vacancies': 2, 'max_pages': 2,
                               'max_retries': 2, 'retry_delay_seconds': 0},
                    'schedule': {'every_hours': 24},
                    'error_report': str(self.path / 'error.json')}
        self.raw = SAMPLE['results']['vacancies'][1]['vacancy']

    def test_model_works_with_team_rules_and_source_quotes(self):
        model = FakeModel()
        with patch('app.ai_integration._model', return_value=model):
            vacancies, issues = main.run_pipeline([self.raw], 'check', self.cfg)
        self.assertEqual(vacancies[0]['ai_status'], 'gemma-local')
        self.assertEqual(model.calls, 1)
        self.assertTrue(any(r['source'] == 'rules' for r in issues[0]))
        found = next(r for r in issues[0] if r['source'] == 'llm')
        self.assertIn(found['quote'], self.raw[found['field']])
        self.assertTrue(any(r.get('recommendation_source') == 'ai-template-choice' for r in issues[0]))

    def test_api_cache_second_run_and_invalidation(self):
        one = FakeModel()
        with patch('app.ai_integration._model', return_value=one):
            first, remarks1 = main.run_pipeline([self.raw], 'api', self.cfg)
        self.assertEqual(one.calls, 1)
        self.assertTrue((self.path / 'cache-v1.json').exists())
        two = FakeModel()
        with patch('app.ai_integration._model', return_value=two):
            second, remarks2 = main.run_pipeline([self.raw], 'api', self.cfg)
        self.assertEqual(two.calls, 0)
        self.assertEqual(two.choices, 0)
        self.assertTrue(second[0]['ai_cache_hit'])
        self.assertEqual(remarks1, remarks2)
        changed = dict(self.raw, duty=self.raw['duty'] + ' Дополнительное условие.')
        three = FakeModel()
        with patch('app.ai_integration._model', return_value=three):
            main.run_pipeline([changed], 'api', self.cfg)
        self.assertEqual(three.calls, 1)

    def test_failure_not_cached_and_check_ignores_cache(self):
        bad = FakeModel(fail=True)
        with patch('app.ai_integration._model', return_value=bad):
            vacancies, _ = main.run_pipeline([self.raw], 'api', self.cfg)
        self.assertEqual(vacancies[0]['ai_status'], 'mixed')
        self.assertFalse((self.path / 'cache-v1.json').exists())
        good = FakeModel()
        with patch('app.ai_integration._model', return_value=good):
            main.run_pipeline([self.raw], 'api', self.cfg)
        retry = FakeModel()
        with patch('app.ai_integration._model', return_value=retry):
            main.run_pipeline([self.raw], 'check', self.cfg)
        self.assertEqual(retry.calls, 1)

    def test_unknown_or_corrupt_model_quote_is_rejected(self):
        class Invalid(FakeModel):
            def analyze(self, v):
                return [{'topic': 'Обязанности', 'field': 'duty', 'quote': 'выдумано',
                         'problem': 'x', 'recommendation': 'y'}]
        with patch('app.ai_integration._model', return_value=Invalid()):
            _, issues = main.run_pipeline([self.raw], 'check', self.cfg)
        self.assertFalse(any(r['source'] == 'llm' for r in issues[0]))

    def test_check_preserves_all_records_even_duplicate_or_missing_id(self):
        cfg = {**self.cfg, 'llm': {'enabled': False}}
        raw = [{'id': 'same'}, {'id': 'same'}, {'duty': 'Работа'}]
        vacancies, issues = main.run_pipeline(raw, 'check', cfg)
        save_report(vacancies, issues, 'check', None, str(self.path / 'report.json'))
        report = json.loads((self.path / 'report.json').read_text(encoding='utf8'))
        self.assertEqual(report['total'], 3)
        self.assertEqual([v['id'] for v in report['vacancies']], ['same', 'same', ''])
        self.assertIsNone(report['model'])

    def test_api_pagination_deduplicates_before_limit(self):
        batches = [[{'id':'1'},{'id':'2'}], [{'id':'2'},{'id':'3'}], [{'id':'4'}]]
        with patch('app.fetch.fetch_page', side_effect=batches) as f:
            result = fetch_vacancies('http://example.invalid', 2, 4, 3)
        self.assertEqual([v['id'] for v in result], ['1', '2', '3', '4'])
        self.assertEqual([c.args[1] for c in f.call_args_list], [0, 2, 4])

    def test_bad_second_page_retries_without_overwrite(self):
        report = self.path / 'report.json'
        report.write_text('old', encoding='utf8')
        class Reply:
            def __init__(self, data): self.data = data
            def raise_for_status(self): pass
            def json(self): return self.data
        responses = [Reply({'results': {'vacancies': [{'vacancy': {'id': '1'}}]}}),
                     Reply({'error': 'bad'})] * 2
        with patch('main.load_config', return_value=self.cfg), patch('main.time.sleep'), \
             patch('app.fetch.requests.get', side_effect=responses) as get, \
             patch('sys.argv', ['main.py', 'run']):
            with self.assertRaises(SystemExit):
                main.main()
        self.assertEqual(report.read_text(encoding='utf8'), 'old')
        self.assertIn('список вакансий не найден', json.loads((self.path / 'error.json').read_text(encoding='utf8'))['error'])
        self.assertEqual(get.call_count, 4)
        with self.assertRaises(ApiError): unwrap({'error':'bad'})

    def test_sample_conflict_and_schedule_with_correct_fields(self):
        cases = {x['vacancy']['id']: x['vacancy'] for x in SAMPLE['results']['vacancies']}
        r4 = next(x for x in check_rules(normalize(cases['DEMO-39-004'])) if x['type'] == 'contradiction' and x['topic'] == 'место работы')
        self.assertEqual(r4['field'], 'duty | requirement.qualification')
        for field, value in zip(r4['field'].split(' | '), r4['values']):
            source = cases['DEMO-39-004']
            for part in field.split('.'): source = source[part]
            self.assertIn(value, source)
        r8 = next(x for x in check_rules(normalize(cases['DEMO-39-008'])) if x['topic'] == 'график')
        self.assertEqual(r8['field'], 'requirement.qualification')
        self.assertIn('Часы указаны', r8['problem'])

    def test_no_false_structured_experience_or_text_salary(self):
        v = normalize({'id': '1', 'salary': '50 000 рублей', 'requirement': {'experience': 0,
                      'qualification': 'Требуется не менее 5 лет опыта работы.'}})
        issues = check_rules(v)
        self.assertFalse(any(x['topic'] == 'оплата' and x['type'] == 'missing' for x in issues))
        self.assertFalse(any(x['topic'] == 'требования' and x['type'] == 'contradiction' for x in issues))

    def test_negated_remote_or_office_is_not_a_conflict(self):
        pairs = [
            ('Полностью дистанционная работа не предусмотрена.', 'Обязательное присутствие в офисе.'),
            ('Работа полностью дистанционная.', 'Обязательное присутствие в офисе не требуется.'),
        ]
        for duty, qualification in pairs:
            v = normalize({'id':'1', 'duty':duty, 'requirement':{'qualification':qualification}})
            self.assertFalse(any(x['topic'] == 'место работы' and x['type'] == 'contradiction' for x in check_rules(v)))

    def test_changed_model_and_cache_corruption_force_new_call(self):
        with patch('app.ai_integration._model', return_value=FakeModel()):
            main.run_pipeline([self.raw], 'api', self.cfg)
        changed = {**self.cfg, 'llm': {**self.cfg['llm'], 'model': 'different-model'}}
        model = FakeModel()
        with patch('app.ai_integration._model', return_value=model):
            main.run_pipeline([self.raw], 'api', changed)
        self.assertEqual(model.calls, 1)

    def test_dedup_keeps_different_quotes(self):
        a = {'source': 'llm', 'type': 'ambiguous', 'topic': 'график', 'field': 'duty',
             'quote': 'одна фраза', 'problem': 'x'}
        b = {**a, 'quote': 'другая фраза'}
        self.assertEqual(len(deduplicate_issues([a, dict(a), b])), 2)

    def test_real_model_interface_with_mocked_transformer_pipeline(self):
        from app.llm import GemmaLocalAnalyzer
        response = [{'topic': 'Обязанности', 'field': 'duty',
                     'quote': 'Выполнение различных поручений руководителя.',
                     'problem': 'Неясны конкретные обязанности.',
                     'recommendation': 'Уточните, какие конкретно поручения будут выполняться.',
                     'severity': 'средняя'},
                    {'topic': 'Требования', 'field': 'requirement.qualification',
                     'quote': 'Готовность работать в динамичной команде.',
                     'problem': 'Неясны требования к навыкам и качествам.',
                     'recommendation': 'Уточните, какие конкретные навыки и качества необходимы.',
                     'severity': 'средняя'}]
        class Tokenizer:
            def apply_chat_template(self, messages, **kwargs): return 'prompt'
        class Pipeline:
            tokenizer = Tokenizer()
            def __init__(self): self.calls = 0
            def __call__(self, prompt, **kwargs):
                self.calls += 1
                text = 'A' if self.calls == 1 else json.dumps(response, ensure_ascii=False)
                return [{'generated_text': text}]
        pipe = Pipeline()
        self.cfg['llm']['model'] = 'google/gemma-2-2b-it'
        with patch.object(GemmaLocalAnalyzer, '_load', return_value=pipe):
            vacancies, issues = main.run_pipeline([self.raw], 'check', self.cfg)
        self.assertEqual(vacancies[0]['ai_status'], 'gemma-local')
        self.assertEqual(pipe.calls, 2)
        self.assertEqual(sum(r['source'] == 'llm' for r in issues[0]), 2)
        self.assertEqual(sum(r.get('recommendation_source') == 'ai-template-choice' for r in issues[0]), 1)

    def test_http_end_to_end_and_cache_second_run(self):
        raw = self.raw
        class Handler(BaseHTTPRequestHandler):
            offsets = []
            def log_message(self, *args): pass
            def do_GET(self):
                offset = int(parse_qs(urlparse(self.path).query)['offset'][0])
                Handler.offsets.append(offset)
                item = {**raw, 'id': str(offset)}
                body = json.dumps({'results': {'vacancies': [{'vacancy': item}]}}, ensure_ascii=False).encode('utf8')
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(body)
        server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(server.server_close)
        self.addCleanup(thread.join, 2)
        self.addCleanup(server.shutdown)
        self.cfg['source']['url'] = 'http://127.0.0.1:%d/vacancies' % server.server_port
        first = FakeModel()
        with patch('main.load_config', return_value=self.cfg), patch('app.ai_integration._model', return_value=first), \
             patch('sys.argv', ['main.py', 'run']):
            main.main()
        self.assertEqual(first.calls, 2)
        second = FakeModel()
        with patch('main.load_config', return_value=self.cfg), patch('app.ai_integration._model', return_value=second), \
             patch('sys.argv', ['main.py', 'run']):
            main.main()
        report = json.loads((self.path / 'report.json').read_text(encoding='utf8'))
        self.assertEqual(report['total'], 2)
        self.assertEqual(report['ai_cache_hits'], 2)
        self.assertEqual(second.calls, 0)
        self.assertEqual(Handler.offsets, [0, 1, 0, 1])

    def test_legacy_cache_is_ignored_and_corrupt_cache_not_used(self):
        (self.path / 'cache.json').write_text('{"oldhash": []}', encoding='utf8')
        (self.path / 'cache-v1.json').write_text('{bad json', encoding='utf8')
        model = FakeModel()
        with patch('app.ai_integration._model', return_value=model):
            vacancies, _ = main.run_pipeline([self.raw], 'api', self.cfg)
        self.assertEqual(model.calls, 1)
        self.assertFalse(vacancies[0]['ai_cache_hit'])

    def test_schedule_runs_once_then_stops(self):
        with patch('main.load_config', return_value={**self.cfg, 'llm': {'enabled': False}}), \
             patch('main.fetch_with_retries', return_value=[self.raw]) as fetch, \
             patch('main.time.sleep', side_effect=KeyboardInterrupt) as sleep, \
             patch('sys.argv', ['main.py', 'schedule']):
            with self.assertRaises(SystemExit) as result: main.main()
        self.assertEqual(result.exception.code, 0)
        fetch.assert_called_once()
        sleep.assert_called_once_with(24*3600)


if __name__ == '__main__':
    unittest.main()
